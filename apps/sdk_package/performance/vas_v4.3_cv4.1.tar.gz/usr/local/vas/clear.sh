#! /bin/bash
rm -f privateKey.pem pubKey.pem r.txt l.txt
