#!/bin/bash

#脚本说明
# 功能:用于vas,历史记录按天分目录保存,并清除指定周期外的日志,无参数.

period_days=$((7))
log_path="/usr/local/vas/vas_data/log"
history_path="/usr/local/vas/vas_data/history/log"

curr_date=$(date -d now +%Y%m%d)
curr_tm=$(date -d "${curr_date}" +%s)

echo "curr_date = ${curr_date}"
echo "log_path = ${log_path}"
echo "history_path = ${history_path}"
echo "period_days = ${period_days} days"


# 判断是否超过有效期
# 输入参数：目期字符串，例如：20180901
function expire_date_path()
{
	tm=`date -d "${1}" +%s`
	ret=$?
	if [ ${ret} -ne 0 ]; then return 1; fi
	
	len=$(((${curr_tm} - ${tm}) / 86400))
	if [ ${len} -le ${period_days} ]; then return 1; fi
	
	return 0
}

# 1.历史记录按天分目录保存
echo "proc vas_log pack ..."
logs=$(ls "${log_path}")
for log in ${logs}
do
	# 格式:info20180903-143243.31619
	if [ ${#log} -lt 12 ]; then
		echo "abort1 file ${log}"
		continue
	fi
	
	strDate=${log:4:8}
	tm=`date -d "${strDate}" +%s`
	ret=$?	
	if [ ${ret} != 0 ]; then
		echo "abort2 file ${log}"
		continue
	fi
	
	if [ "${strDate}" == "${curr_date}" ]; then
		echo "abort3 file ${log}"
		continue
	fi
	
	date_path="${history_path}/${strDate}"	
	if [[ ! -d ${date_path} ]]; then
		mkdir -p ${date_path}
	fi
	
	log_file="${log_path}/${log}"
	echo "mv ${log_file} ${date_path}"
	mv "${log_file}" "${date_path}"
done


# 2.清除到期日志
echo "proc vas_log delete ..."
dates=$(ls "${history_path}")
for date in ${dates}
do
	expire_date_path "${date}"
	ret=$?
	if [ ${ret} == 0 ]; then
		date_path="${history_path}/${date}"
		echo "rm ${date_path} ..."
		rm -fr "${date_path}"	
	fi
done

echo "finished."
exit 0
