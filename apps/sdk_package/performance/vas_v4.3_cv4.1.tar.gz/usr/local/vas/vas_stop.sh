#!/bin/bash

#脚本说明
# 功能:用于停止vas,成功返回0,其它返回非0,无参数.

# 服务是否启动
pids=$(pidof vas)
if [ -z "${pids}" ]; then
	echo "vas already exit."
	exit 0;
fi

# 停止
pidof vas | xargs kill -s term 
sleep 3
pids=$(pidof vas)
if [ -z "${pids}" ]; then
	echo "stop succeed."
	exit 0
else
	echo "stop failed, please check."
	echo "${pids}"
	exit -1
fi


