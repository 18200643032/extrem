# 目录
* [简介](#简介)
* [编译](#编译)
* [安装](#安装)
* [部署](#部署)
* [运维](#运维)
* [本地配置](#本地配置)
* [运行参数](#运行参数)
* [callback信息](#callback信息)
* [ice服务](#ice服务)
* [http服务](#http服务)

# 简介
* 基于ev_sdk:v2.0标准，提供基于实时流的算法分析服务
* vas标准版本，适用于报警类、统计类、分类等算法
* vas软件最终以安装包的形式发布，工作目录`/usr/local/vas`
* 若vas，流媒体需要安装在同一个docker内，建议先安装流媒体，请参考[流媒体](http://git.extremevision.com.cn/ExtremeVision/nginx)

# 编译

	源码目录结构如下
    ├── README.md               # 本帮助文档
    ├── ready.sh                # 准备脚本
    ├── doc                     # 相关文档，例如ice服务，http服务帮助文档
    ├── bin                     # 待安装文件、打包脚本、安装脚本、各版本安装包
    ├── ice                     # ice文件
    ├── 3rd                     # 第三方依赖库，例如ffmpeg_player、license
    ├── src                     # vas源码
    └── test                    # testVas源码

### ffmpeg_player编译
* 先拉取源码`git clone git@git.extremevision.com.cn:ExtremeVision/vas_standard.git`，进入源码目录，运行准备脚本`./ready.sh`
* 运行命令`cd 3rd/ffmpeg_player/build && cmake ../ && make -j && make install`进行编译，生成三个目标文件libffmpeg_player.so、testPlay、testPlayAndRtmp，同时会自动复制到`bin/usr/local/vas`目录
* 运行`./bin/usr/local/vas/testPlayer`或`./bin/usr/local/vas/testPlayAndRtmp`会输出使用帮助

### vas编译
* 运行命令`cd src && make -j`进行编译，生成目标文件vas，同时会自动复制到`bin/usr/local/vas`目录
* 运行`./bin/usr/local/vas/vas`会输出使用帮助

### testVas编译
* 运行命令`cd test && ./compile`进行编译，生成目标文件testVas，同时会自动复制到`bin/usr/local/vas`目录
* 运行`./bin/usr/local/vas/testVas`会输出使用帮助

### 安装包
* 运行命令`cd bin && ./package`进行安装包，生成tar包文件，例如 **vas_v3.8.tar.gz**
* tar包文件名中包括版本信息，版本信息在`./src/server.h`文件中，例如 **#define VAS_VERSION  "version:v3.8"**

# 安装
* 安装包存放在`./bin`目录下，文件名包括版本号
* 运行命令，例如 `cd bin && ./install vas_v3.8.tar.gz aid`，会自动安装在`/usr/local/vas`目录下
* 安装完成后，会自动启动服务，运行命令`pidof vas`会输出服务的进程id

### 目录结构如下

    安装目录:/usr/local/vas
    ├── README.md               # 本帮助文档，MarkDown格式
    ├── README.html             # 本帮助文档，html格式
    ├── http.html               # http服务文档，html格式
    ├── http.md                 # http服务文档，MarkDown格式
    ├── ice.html                # ice服务文档，html格式
    ├── ice.md                  # ice服务文档，MarkDown格式
    ├── v_service_interface.ice # ice服务接口文件
    ├── core_dump.log           # vas异常退出时生成的core_dump文件
    ├── local.conf              # 本地配置文件
    ├── config.server           # ICE服务配置文件
    ├── right_ice.client        # 主备锁客户端连接配置文件(暂时未启用)
    ├── run.conf                # 运行参数，有算法配置工具下发，安装时没有该文件
    ├── oneKeyTest.sh           # 一键测试license脚本
    ├── oneKeyTest_n.sh         # 一键测试license脚本，用于联网license校验
	├── clear.sh                # 一键测试license清除脚本
	├── generateRsaKey.sh       # RSA密钥生成脚本
    ├── ev_codec                # 字符串混编及常量字符串硬编码工具，直接运行会输出帮助(其它工具也一样)
    ├── ev_license              # license工具
    ├── testVas                 # ICE服务测试工具，以下七个是对应的测试文件
    ├── run.conf.1              # 运行参数，第一版示例
    ├── run.conf.2              # 运行参数，第二版单路示例
    ├── run.conf.3              # 运行参数，第二版多路示例
    ├── get_reference.sample    # 获取参考码示例
    ├── query_license.sample    # 查询license示例
    ├── update_license.sample   # 更新或清除license示例
    ├── algo_config.sample      # 算法配置参数示例
    ├── testPlay                # 基于ffmpeg的测试rtsp，rtmp，htt-flv，hls流工具
    ├── testPlayAndRtmp         # 同上，增加rtmp推流测试
    ├── libffmpeg_player.so     # 拉流、编解码、推流依赖库
    ├── vas_data -> /data/${container_id}/vas_data  # 用于存放日志和报警图片，软链接目录，指向docker宿主机
        ├── log                     # glog日志目录
        └── pic                     # 报警图片目录 
    ├── vas                     # 服务程序 
    ├── vas.sh                  # 服务程序启动脚本，内部调用vas
    ├── vas_start.sh            # 服务程序高级启动脚本，内部调用vas.sh
    ├── vas_start_container.sh  # 服务程序高级启动脚本，用于容器启动时调用
    ├── vas_stop.sh             # 服务程序停止脚本
    ├── start_all.sh            # 若vas和nginx同时安装，一起启动的脚本，内部会调用vas_start.sh
    ├── stop_all.sh             # 若vas和nginx同时安装，一起启动的脚本，内部会调用vas_stop.sh
    ├── vas_log_delete.sh       # 周期内移除日志文件，请配置在crontab
    └── vas_pic_delete.sh       # 周期内移除报警图片文件，请配置在crontab
	
# 部署
### 拉镜像
例如  `docker pull tdocker-registry.cvmart.net/具体算法sdk_for_vas镜像`

### 创建并运行容器
例如 `docker run -it --runtime=nvidia --privileged -v /dockerdata/AppData:/data -p 10000:10000 -e LANG=C.UTF-8 tdocker-registry.cvmart.net/具体算法sdk镜像 /bin/bash`

**参数备注**

 * `--privileged`:用于container获取容器id等信息；
 * `-v`:容器内数据直接映射到本地宿主机，创建container时需要根据实际指定宿主机的目录，container目录不用指定；
 * `-p`:端口映射，详见端口备注

**端口备注**
 
`10000`:vas的ice服务占用，例如:apply，test，algoConfig，status，qpsInfo，license；

**license的生成**

正常情况下，license的生成有算法配置管理工具下发，但知道rsa私钥的前提下也支持本地生成，例如
 
 * 先在vas工作目录，运行`./ev_license -r r.txt`，生成摘要并保存在r.txt文件内；  
 * 然后运行`./ev_license -l 私钥文件 r.txt l.txt`，生成license并保存在1.txt文件内；
 * 运行`./ev_license -c 公钥文件 l.txt`，对生成的license进行校验，以便确认是否成功，该步骤选做；
 * 最后把license文件（json格式）的内容相应的更改到本地配置文件local.conf内即可。 

# 运维
### 启停服务
发布软件已做软链接，实现在任意目录下启停服务，例如 
 
 	ln -s /usr/local/vas/vas_start.sh /usr/bin/vas_start
 	ln -s /usr/local/vas/vas_stop.sh /usr/bin/vas_stop
 
 * 启动: `vas_start` 或 `./vas_start.sh`
 * 停止: `vas_stop` 或 `./vas_stop.sh`
 * 查询: `ps -ef | grep vas` 或 `pidof vas`

### 运行日志查询
`cd /usr/local/vas && tail -f vas_data/log/vas.INFO`

### 清除历史报警图片
清除glog日志脚本`/usr/local/vas/vas_pic_delete.sh`，配置到定时任务即可。

### 清除glog日志
清除glog日志脚本`/usr/local/vas/vas_log_delete.sh`，配置到定时任务即可。

# 本地配置
local.conf示例
	
	;[license]
	;license    授权码
	;url        联网license校验http地址
	;activation 激活码
	;timestamp  授权码有效期
	;qps        请求量上限
	;version    授权码版本
	[license]
	license=
	url=
	activation=
	timestamp=
	qps=
	version=
	
	;[local]
	;aid 算法ID
	;server_mode       服务模式，支持`ice`、`http`、`ice & http`，默认开启ice和http服务
	;http_port         http-server服务端口号，默认80
	;run_conf          运行参数，有算法管理平台下发，本地保存
	;config_server ice 服务配置
	;right_ice         主备锁ice客户端配置
	;log_path          glog日志记录路径及名称（基本）
	;pic_path          图片保存路径
	;algo_conf         算法配置文件全路径，默认/usr/local/ev_sdk/model/algo_config.json
	[local]
	aid=9999
	server_mode=ice & http
	http_port=80
	run_conf=/usr/local/vas/run.conf
	config_server=/usr/local/vas/config.server
	right_ice=/usr/local/vas/right_ice.client
	log_path=/usr/local/vas/vas_data/log/info
	pic_path=/usr/local/vas/vas_data/pic
	algo_conf=/usr/local/ev_sdk/model/algo_config.json
	
	;[option]
	;enable_lock   是否启用主备锁 0不启用 1启用，可选
	;frame_buffers 解码缓冲帧数,1..50之间（仅在不抽帧模式下有效）
	;cb_threads    http协议callback线程数，默认为1
	[option]
	enable_lock=0
	frame_buffers=5
	cb_threads=1

    
# 运行参数
平台通过vas提供的ICE服务接口功能下发，成功后会保存到文件`run.conf`.

**第一版（仅支持单路，保留）**

    {
        "cid": "123456",
        "cid_url": "rtsp://admin:extremevision201@192.168.1.34:554/h264/ch1/sub/av_stream",
        "gpu_id": -1,
        "begin_time": "00:00:00", 
        "end_time": "23:59:59", 
        "decoding_only_keyframes": false, 		
        "interval": 0, 
        "callback_interval": 30, 
        "whether_callback_srcpic": true, 
        "whether_callback_pic": true, 
        "call_back": "http://face01.cvmart.net/api/testice", 
        "push_url": "rtmp://localhost/echostream/123456",
        "algo": [
        	{
    			"params": "POLYGON((0.001 0.001, 0.001 0.999, 0.999 0.999, 0.999 0.001))"
    		}
		]
    }

**参数说明**

* cid:摄像头ID，必填；
* cid_url:摄像头对应拉流地址，支持rtsp，rtmp，http-flv，必填；
* gpu_id:针对gpu算法，表示对应的gpu_id序号，可选(默认为-1，表示不同步)，大于等于0时有效且同步到算法配置文件，在vas重启服务线程时同步，运行参数更改均会触发服务线程重启；
* begin_time，end_time:算法运行时间段，可选(默认没有效时间段)，要么不填，要么全填，不可以只填一个；
* decoding_only_keyframes:是否只解码关键帧，可选（默认解码所有帧）；
* interval:检间间隔，表示取一帧的最小时长，包括算法分析一帧的耗时，单位为毫秒，可选(默认不启用；小于等于0表示不启用)，取值范围:33ms--900*1000ms；
* callback_interval:报警上传间隔，单位为秒，可选(默认启用，值为30秒），小于等于0表示不启用；
* whether_callback_srcpic:报警上传时是否上传源图片，可选(默认上传)；
* whether_callback_pic:报警上传时是否上传报警图片，可选(默认上传)；
* call_back:算法运行结果回调，仅支持http协议，可选(默认不启用)；
* push_url:算法运算结果推流地址，仅支持rtmp协议，可选(默认不启用)；
* algo:算法运行参数，可选(每个算法的参数有所不同，请参考运行参数格式示例).
 	* 如果是数组，按之前方式解析，即解析出params的值传给算法
	* 如果是对像，直接透传给算法

**第二版（支持单路和多路，建议使用）**

    {
        "mode": "multi", 
        "gpu_id": -1,
        "begin_time": "00:00:00", 
        "end_time": "23:59:59", 
        "poll_sequential_frames": 1, 
        "decoding_only_keyframes": false, 
        "interval": 0, 
        "callback_interval": 30, 
        "whether_callback_srcpic": true, 
        "whether_callback_pic": true, 
        "call_back": "http://face01.cvmart.net/api/testice", 
        "push_url": "rtmp://localhost/echostream/123450", 
        "camera_list": [
            {
                "cid": "123450",
                "cid_url": "rtsp://admin:extremevision201@192.168.1.34:554/h264/ch1/sub/av_stream",
                "algo": [
                    {
                        "params": "POLYGON((0.001 0.001, 0.001 0.999, 0.999 0.999, 0.999 0.001))"
                    }
                ]
            },
            {
                "cid": "123451",
                "cid_url": "rtsp://admin:extremevision201@192.168.1.36:554/ch1/sub/h264",
                "algo": [
                    {
                        "params": "POLYGON((0.001 0.001, 0.001 0.999, 0.999 0.999, 0.999 0.001))"
                    }
                ]
            },
            {
                "cid": "123452",
                "cid_url": "rtsp://admin:admin@192.168.1.37:554/ch1/sub/h264",
                "algo": [
                    {
                        "params": "POLYGON((0.001 0.001, 0.001 0.999, 0.999 0.999, 0.999 0.001))"
                    }
                ]
            }
        ]
    }

**参数说明**

* mode:工作方式，固定为`multi`，必填；
* gpu_id:针对gpu算法，表示对应的gpu_id序号，可选(默认为-1，表示不同步)，大于等于0时有效且同步到算法配置文件，在vas重启服务线程时同步，运行参数更改均会触发服务线程重启；
* begin_time，end_time:算法运行时间段，可选(默认没有效时间段)，要么不填，要么全填，不可以只填一个；
* poll_sequential_frames:多路轮询连续送帧数，可选（默认1，表示不启用），仅在配了多路且该值大于1时启用(缓冲固定为2)；
* decoding_only_keyframes:是否只解码关键帧，可选（默认解码所有帧）；
* interval:检测间隔，取值范围:33ms--900*1000ms，单位为毫秒，该选项决定对源视频的取帧频率，可选(默认不启用；小于等于0表示不启用)；
	* 配置单路时，表示取一帧的最小时长，包括算法分析一帧的耗时
	* 配置多路时，表示检测一轮时的最小时长，包括算法分析一轮的耗时
	* 启用多路轮询送帧功能时，表示取一帧的最小时长，包括算法分析一帧的耗时，即与配置单路时取帧方式一致
* callback_interval:报警上传间隔，单位为秒，可选(默认启用，值为30秒），小于等于0表示不启用；
* whether_callback_srcpic:报警上传时是否上传源图片，可选(默认上传)；
* whether_callback_pic:报警上传时是否上传报警图片，可选(默认上传)；
* call_back:算法运行结果回调地址，仅支持http协议，可选(默认不启用)；
* push_url:算法运算结果推流地址，仅支持rtmp协议，可选(**配置多路时不生效**)；
* camera_list:视频源列表，必填(数组类型，成员信息如下)；
* cid:摄像头ID，必填；
* cid_url:摄像头对应拉流地址，支持rtsp，rtmp，http-flv，hls协议，必填;
* algo:算法运行参数，选填(每个算法的参数有所不同，请参考运行参数格式示例).
	* 如果是数组，按之前方式解析，即解析出params的值传给算法
	* 如果是对像，直接透传给算法

# callback信息
若运行参数配置了call_back地址（http服务），即可接收call_back信息，示列如下

    {
        "aid": "9999",
        "cid": "123450",
        "cid_url": "rtsp://admin:extremevision201@192.168.1.34:554/h264/ch1/sub/av_stream",
        "time_stamp": 1547263334, # $(date -d @1547263334 "+%Y-%m-%d %H:%M:%S") 
        "status": 1,
        "srcpic_name": "20181031115828_363236_123450_in.jpg",
        "srcpic_data": "base64",
        "pic_name": "20181031115828_363236_123450_out.jpg",
        "pic_data": "base64",
        "data": "算法返回的数据，详见对应算法输出json的相关文档"
    }

**参数说明**

* aid:算法ID，对应本地配置文件aid；
* cid:摄像头ID，对应运行参数cid；
* cid_url:摄像头拉流地址，对应运行参数cid_url；
* time_stamp:算法分析的时间，1970-01-01 00:00:00至今的秒数，参考命令`date -d now +%s`， `date -d @1547263334 "+%Y-%m-%d %H:%M:%S"`；
* status:报警状态，1为报警，其它为非报警；
* srcpic_name:报警帧原始图片文件名，格式为:`yyyymmddHHMMSS_US_cid_in.jpg`，运行参数启用`whether_callback_srcpic`时才生效；
* srcpic_data:报警帧原始图片数据，base64编码，运行参数启用`whether_callback_srcpic`时才生效；
* pic_name:算法返回的报警图片文件名，格式为:`yyyymmddHHMMSS_US_cid_out.jpg`，运行参数启用`whether_callback_pic`时才生效；
* pic_data:算法返回的报警图片数据，base64编码，运行参数启用`whether_callback_pic`时才生效；
* data:算法返回的json数据，是一个是json对像("{}")，每个算法返回的数据格式有所不同，具体请参考对应算法输出json的相关文档。

# ice服务
详见`doc/ice.md`文件

# http服务
详见`doc/http.md`文件

---
