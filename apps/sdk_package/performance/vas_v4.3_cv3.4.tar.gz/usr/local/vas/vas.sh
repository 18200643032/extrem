#! /bin/bash

cd /usr/local/vas
./vas --conf local.conf 
