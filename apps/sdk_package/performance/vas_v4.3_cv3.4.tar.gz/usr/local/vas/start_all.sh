#!/bin/bash

#脚本说明
# 功能:用于启动nginx,vas服务,无参数.

# nginx
/usr/local/nginx/script/nginx_start.sh

# vas
/usr/local/vas/vas_start.sh

exit 0



