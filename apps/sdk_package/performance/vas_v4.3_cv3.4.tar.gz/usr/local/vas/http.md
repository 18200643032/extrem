# 目录
* [简介](#简介)
* [运行参数设置](#运行参数设置)
* [运行参数设置test](#运行参数设置test)
* [算法参数设置](#算法参数设置)
* [获取运行参数](#获取运行参数)
* [获取算法参数](#获取算法参数)
* [服务状态查询](#服务状态查询)
* [qps信息查询](#qps信息查询)
* [授权服务](#授权服务)
	* [获取参考码](##获取参考码)
	* [修改授权信息](##修改授权信息)
	* [获取授权信息](##获取授权信息)
	* [清除授权信息](##清除授权信息)
 	
# 简介
* 本地配置文件`local.conf`：`server_mode`选项设置为`http`或`ice & http`，默认启用ice及http服务

* http服务端口有本地配置文件`local.conf`：`http_port`选项设置，默认为80

# 运行参数设置
设置vas的运行参数并立即生效

* 请求
	* 路径`/api/apply`，`POST`方法
	* 请求body为json数据，详细请参考`README.md`:`运行参数`
	* 示例

			{
			    "mode": "multi",
			    "gpu_id": -1,
			    "begin_time": "00:00:00",
			    "end_time": "23:59:59",
			    "poll_sequential_frames": 1,	
			    "decoding_only_keyframes": false,
			    "interval": 0,
			    "callback_interval": 30,
			    "whether_callback_srcpic": true,
			    "whether_callback_pic": true,
			    "call_back": "http://face01.cvmart.net/api/testice",
			    "push_url": "rtmp://localhost/echostream/123450",
			    "camera_list": [
			        {
			            "cid": "123450",
			            "cid_url": "rtsp://admin:extremevision201@192.168.1.34:554/h264/ch1/sub/av_stream",
			            "algo": [
			                {
			                    "params": "POLYGON((0.001 0.001, 0.001 0.999, 0.999 0.999, 0.999 0.001))"
			                }
			            ]
			        }
			    ]
			}

* 返回
	* 200，返回json格式数据，`Content-Type:application/json`
	* 成功，示例
 	
			{
				"code": 0,
				"result": {"err_code":0,"err_msg":"succeed"}
			}

	* 失败，示例
	
			{
				"code": -1，
				"result": "parameter error"
			}
			或 	
			{
				"code": -2，
				"result": {"err_code":-1,"err_msg":"parameter error"}
			}

		* code:错误号，通常是-2
		* result:错误信息，是个对像
			* err_code:内部错误号
			* err_msg:错误描述
		  
**备注**

请求返回失败时，所有服务均是该格式

# 运行参数设置test
同运行参数设置，但是仅测试，不生效
	 
* 请求
	* 路径`/api/apply`，`POST`方法

# 算法参数设置
设置算法配置参数并立即生效

* 请求
	* 路径`/api/algoConfig`，`POST`方法
	* url地址带`fullPath`可选参数，需要用url_encode编码，表示算法配置文件全路径，默认是`/usr/local/ev_sdk/model/algo_config.json`
	* 请求body为json数据，每个算法配置参数可能有所不同，由具体算法为准。
	* 示例

			算法基本配置参数如下
			{
	    		"draw_roi_area":1,
			    "draw_result":1,
	    		"show_result":0,
	    		"gpu_id":0,
	    		"threshold_value":0.5
			}	

		* draw_roi_area:是否绘制感兴趣区域，默认为1
		* draw_result:是否绘制检测结果信息，默认为1
		* show_result:实时显示算法分析图片，默认为0
		* gpu_id:gpu序号，仅对gpu算法有效，默认为0
		* threshold_value:阈值，默认为0.5

* 返回
 * 200，返回json格式数据，`Content-Type:application/json`
 * 成功，示例
 	
			{
				"code": 0,
				"result": {"err_code":0,"err_msg":"succeed"}
			}

# 获取运行参数
获取已落地的运行参数

* 请求
	* 路径`/api/getRunConfig`，`GET`方法，无参
* 返回	
	* 200，返回json格式数据，`Content-Type:application/json`
	* 成功，返回运行参数，详细请参考README.md:运行参数，示例
	
			{
			  "code": 0,
			  "result": {
			    "mode": "multi",
			    "begin_time": "00:00:00",
			    "end_time": "23:59:59",
			    "decoding_only_keyframes": false,
			    "interval": 0,
			    "callback_interval": 10,
			    "whether_callback_srcpic": true,
			    "whether_callback_pic": true,
			    "call_back": "http://192.168.1.175:81/api/callback/handle",
			    "camera_list": [
			      {
			        "cid": "123450",
			        "cid_url": "rtsp://admin:extremevision201@192.168.1.35:554/h264/ch1/sub/av_stream",
			        "algo": [
			          {
			            "params": "POLYGON((0.001 0.001, 0.001 0.999, 0.999 0.999, 0.999 0.001))"
			          }
			        ]
			      }
			    ]
			  }
			} 

# 获取算法参数
获取已落地的运行参数

* 请求
	* 路径`/api/getAlgoConfig`，`GET`方法
	* url地址带`fullPath`可选参数，需要用url_encode编码，表示算法配置文件全路径，默认是`/usr/local/ev_sdk/model/algo_config.json`
	
* 返回	
	* 200，返回json格式数据，`Content-Type:application/json`
	* 成功，返回算法配置参数，每个算法配置参数可能有所不同，由具体算法为准，示例
	
			{
			  "code": 0,
			  "result": {
			    "draw_roi_area": 1,
			    "draw_result": 1,
			    "show_result": 0,
			    "gpu_id": 0,
			    "threshold_value": 0.6
			  }
			}
	
# 服务状态查询
获取vas当前运行状态信息

* 请求
	* 路径`/api/status`，`GET`方法，无参
* 返回
	* 200，返回json格式数据，`Content-Type:application/json`
	* 成功，示例
 	
			{
			  "code": 0,
			  "result": {
			    "whether_authorized": true,
			    "license_data": {
			      "license": "b52f92d8ad261f16e8cafe2a2f6f9589d2f8c77533b92c0f644cf1058557e52a128fe369318f3af5bf6bf229f70bf48820df293dc7dbaf5431e02963e5e3b942febe6ca45de5bee2c1080d91467cdcedfa55555e47bc4955ac3d4e2cbdf6312ec0831a26f1d100f1921576a195aa1666a078ccf6515b40b4060cc08369485532",
			      "version": 7
			    },
			    "whether_run_config": true,
			    "whether_running": true,
			    "whether_multi_camera": false,
			    "whether_acquire_lock": true,
			    "whether_time_segment": true,
			    "whether_time_segment_ok": true,
			    "whether_callback": true,
			    "whether_callback_ok": 1,
			    "whether_push_url": false,
			    "whether_push_url_ok": 0,
			    "camera_list": [
			      {
			        "cid": "123450",
			        "whether_connected": true
			      }，
			      {
			        "cid": "123451",
			        "whether_connected": true
			      }
			    ]
			  }
			}

	* whether_authorized:是否授权，通过授权才有以下所有信息
		* license_data:授权的相关信息，是个json对象
		* whether_run_config:是否有运行参数，有运行参数时才有以下所有信息
			* whether_running:工作线程是否在运行，在运行时才有以下所有信息
				* whether_multi_camera:是否配置了多路摄像头
				* whether_acquire_lock:是否请求到可运行锁
				* whether_time_segment:是否有运行时间段
				* whether_time_segment_ok:当前是否处在运行时间段内
				* whether_callback:是否配置了callback地址(http)
				* whether_callback_ok:最近一次报警回调是否成功--没有配置或没触发调用时为0，失败为-1，成功为1
				* whether_push_url:是否配置推流地址(rtmp)
				* whether_push_url_ok:最近一次推流是否成功--没有配置或多路或没触发调用时为0，失败为-1，成功为1
				* camera_list:摄像头状态信息，是个json数组，成员信息如下{cid,whether_connected}
				* cid:摄像头ID
				* whether_connected:是否连接成功


	* 该接口可用于存活检测，例如:除vas进程不存在、status接口调用不成功外、`(whether_authorized && whether_run_config && !whether_running)`也表示处在卡死状态

# qps信息查询
获取qps相关信息，包括授权中配置的qps，及实际运行的qps（一秒内可处理的帧数）

* 请求
	* 路径`/api/qpsInfo`，`GET`方法，无参
* 返回	
	* 200，返回json格式数据，`Content-Type:application/json`
	* 成功，示例
			
			{
			    "code": 0,
			    "result": {
			        "auth_qps": 0,
			        "real_qps": 143.32
			    }
			}
	
		* code:返回值，0表示成功，其它表示失败
		* auth_qps:授权时的qps，没有授权为-1，授权无qps为0，其它为授权的qps值
		* real_qps:实际部署时qps值，动态计算取得（最近10次实际qps的平均值），没跑过算法时为0.00

# 授权服务
* 请求
	* 路径`/api/license`，`POST`方法
	* 请求body为json数据，提供获取参考码，修改授权信息，获取授权信息，清除授权信息四个功能 
* 返回
 * 200，返回json格式数据，`Content-Type:application/json`

## 获取参考码
* 请求
 * 示例

			｛
				"function": "get_reference",
				"isNetworking": 0
			｝

		* function:固定为`get_reference`
		* isNetworking:是否请求联网校验的参考码，1表示是，其它表示否，默认否，可选参数 
	
* 返回
 * 成功，示例 

			{
				"code": 0,
				"result": {
					"version": 7,
					"reference": "4ecf97189dfb9d94df43d9d14fe754ebf2707c614a50a09d5eed8ea953656695",
					"disk_serial": "S3YLNX0K533123P",
					"mac": "02:42:ac:11:00:0d"
				}
			}

		* code:返回值，0表示成功，其它表示失败
		* result:表示返回的参考码相关信息，其中
			* version:版本号
			* reference:参考码
			* 其它信息（版本不同也有所不同）

## 修改授权信息
* 请求
 * 示例

			{
				"function": "update_license",
				"version": 7,
				"license": "b52f92d8ad261f16e8cafe2a2f6f9589d2f8c77533b92c0f644cf1058557e52a128fe369318f3af5bf6bf229f70bf48820df293dc7dbaf5431e02963e5e3b942febe6ca45de5bee2c1080d91467cdcedfa55555e47bc4955ac3d4e2cbdf6312ec0831a26f1d100f1921576a195aa1666a078ccf6515b40b4060cc08369485532",
				"activation": "RDVG4RDVGFPC99993EA19F8334F667714CC5168D39BC3B0B052C2961F506AAAA"
			}

		* function:固定为`update_license`
		* license:授权码
		* url:联网校验服务器地址(http服务)，可选参数
		* activation:激活码，可选参数
		* timestamp:过期时间，可选参数
		* qps:最大请求量，可选参数
		* version:版本号
	
* 返回
 * 成功，示例 

			{
				"code": 0,
				"result": {"err_code":0,"err_msg":"succeed"}
			}

## 获取授权信息
* 请求
 * 示例

			｛
				"function": "query_license"
			｝

			* function:固定为`query_license`
	
* 返回
 * 成功，示例 

			{
				"code": 0,
				"result": {
					"license": "b52f92d8ad261f16e8cafe2a2f6f9589d2f8c77533b92c0f644cf1058557e52a128fe369318f3af5bf6bf229f70bf48820df293dc7dbaf5431e02963e5e3b942febe6ca45de5bee2c1080d91467cdcedfa55555e47bc4955ac3d4e2cbdf6312ec0831a26f1d100f1921576a195aa1666a078ccf6515b40b4060cc08369485532",
					"activation": "RDVG4RDVGFPC99993EA19F8334F667714CC5168D39BC3B0B052C2961F506AAAA",
					"version": 7
				}
			}

		* code:返回值，0表示成功，其它表示失败
		* result:授权信息 
			* license:授权码
			* activation:激活码
			* version:版本号

## 清除授权信息
* 请求
 * 示例

			{
				"function": "update_license"
			}

			* function:固定为`update_license`
			* 无license相关信息
	
* 返回
 * 成功，示例 

			{
				"code": 0,
				"result": {"err_code":0,"err_msg":"succeed"}
			}

---