#!/bin/bash

#脚本说明
# 功能:用于vas,并清除指定周期外的报警图片,无参数.

period_days=$((7))
pic_path="/usr/local/vas/vas_data/pic"

curr_date=$(date -d now +%Y%m%d)
curr_tm=$(date -d "${curr_date}" +%s)

echo "curr_date = ${curr_date}"
echo "pic_path = ${pic_path}"
echo "period_days = ${period_days} days"

# 判断是否超过有效期
# 输入参数：目期字符串，例如：20180901
function expire_date_path()
{
	tm=`date -d "${1}" +%s`
	ret=$?
	if [ ${ret} -ne 0 ]; then return 1; fi
	
	len=$(((${curr_tm} - ${tm}) / 86400))
	if [ ${len} -le ${period_days} ]; then return 1; fi
	
	return 0
}

pics=$(ls "${pic_path}")
for pic in ${pics}
do
	# 格式:20180719121005_55555_out.jpg
	if [ ${#pic} -lt 14 ]; then
		echo "abort file ${pic}"
		continue
	fi
	
	strDate=${pic:0:8}
	expire_date_path "${strDate}"
	ret=$?
	if [ ${ret} == 0 ]
	then
		pic_file="${pic_path}/${pic}"
		echo "rm ${pic_file} ..."
		rm -f "${pic_file}"	
	fi
done

echo "finished."
exit 0
