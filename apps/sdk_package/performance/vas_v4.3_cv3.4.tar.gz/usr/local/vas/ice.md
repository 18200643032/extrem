# 目录
* [简介](#简介)
* [ice文件](#ice文件)
* [运行参数](#运行参数)
* [运行参数test](#运行参数test)
* [算法配置参数](#算法配置参数)
* [获取运行参数](#获取运行参数)
* [获取算法参数](#获取算法参数)
* [服务状态信息](#服务状态信息)
* [qps信息](#qps信息)
* [授权管理](#授权管理)
* [测试工具](#测试工具)
 	
# 简介
* vas默认会开启ice服务，以便响应上层的相关请求，详细配置请参考安装目录下`config.server`文件

* ice服务唯一字符串标识为`vas`，默认端口为`10000`

* 安装目录下`v_service_interface.ice`是ice文件

* 安装目录下`testVas`是测试工具，直接运行会输出使用帮助

* 源码目录下`test/testVas.cpp`是调用示例 

# ice文件
v_service_interface.ice

	module vas {
	    exception AnalysisException
	    {
	        /**
	         *
	         * The reason why the message was rejected by the server.
	         *
	         **/
	        string reason;
	    };
	
	    class VasiResult {
	        bool bRet;
	        string strRlt;
	    };
	
	    interface vasi
	    {
	        /* 运行参数配置 */
	        bool apply(string config) throws AnalysisException;
	
	        /* 运行参数配置是否正确--仅测试 */
	        bool test(string config) throws AnalysisException;
	
	        /* 算法配置参数--覆写 */
	        bool algoConfig(string config,string fullPath) throws AnalysisException;
	
			//获取运行参数
	        VasiResult getRunConfig() throws AnalysisException;
	
			//获取算法配置参数
	        VasiResult getAlgoConfig(string fullPath) throws AnalysisException;
	
	        /* 获取服务状态信息 */
	        VasiResult status() throws AnalysisException;
	        
	        /* 获取qps信息 */
	        VasiResult qpsInfo() throws AnalysisException;
	
	        /* 授权码相关 */
	        VasiResult license(string content) throws AnalysisException;
	    };
	};


# 运行参数
### 原型
bool apply(string config) throws AnalysisException

### 功能
设置vas的运行参数并立即生效

### 参数
* config:运行参数，详细请参考`README.md`:`运行参数`

### 返回值
成功返回true，失败返回false

# 运行参数test
### 原型
bool test(string config) throws AnalysisException

### 功能
测试config代表的运行参数是否合法，仅测试用，也可以用于心跳检测

### 参数
* config:运行参数，详细请参考`README.md`:`运行参数`

### 返回值
成功返回true，失败返回false

# 算法配置参数
### 原型
bool algoConfig(string config,string fullPath) throws AnalysisException

### 功能
设置算法配置参数并立即生效。

先覆写算法配置文件，由fullPath参数指定，默认是`/usr/local/ev_sdk/model/algo_config.json`。

释放先前创建的检测器实例（如果存在），再创建新的检测器实例。

### 参数
* config:算法配置参数，每个算法配置参数可能有所不同，由具体算法为准。

	算法基本配置参数如下

		{
    		"draw_roi_area":1,
		    "draw_result":1,
    		"show_result":0,
    		"gpu_id":0,
    		"threshold_value":0.5
		}	

	* draw_roi_area:是否绘制感兴趣区域，默认为1
	* draw_result:是否绘制检测结果信息，默认为1
	* show_result:实时显示算法分析图片，默认为0
	* gpu_id:gpu序号，仅对gpu算法有效，默认为0
	* threshold_value:阈值，默认为0.5
* fullPath:算法配置文件名全路径，为空时获取本地配置文件`local.conf:algo_conf`，默认是`/usr/local/ev_sdk/model/algo_config.json`

### 返回值
成功返回true，失败返回false

# 获取运行参数
### 原型
VasiResult getRunConfig() throws AnalysisException;

### 功能
获取已落地的vas运行参数

### 参数
无参数

### 返回值
函数调用后返回VasiResult。其中bRet表示成功与否，strRlt表示具体信息。

* bRet表示成功时，strRlt表示运行参数，详细请参考README.md:运行参数

		{
		    "mode": "multi",
		    "begin_time": "00:00:00",
		    "end_time": "23:59:59",
		    "decoding_only_keyframes": false,
		    "interval": 0,
		    "callback_interval": 10,
		    "whether_callback_srcpic": true,
		    "whether_callback_pic": true,
		    "call_back": "http://192.168.1.175:81/api/callback/handle",
		    "camera_list": [
		      {
		        "cid": "123450",
		        "cid_url": "rtsp://admin:extremevision201@192.168.1.35:554/h264/ch1/sub/av_stream",
		        "algo": [
		          {
		            "params": "POLYGON((0.001 0.001, 0.001 0.999, 0.999 0.999, 0.999 0.001))"
		          }
		        ]
		      }
		    ]
		  }
		
* bRet表示失败时，strRlt表示具体的失败信息


# 获取算法参数
### 原型
VasiResult getAlgoConfig(string fullPath) throws AnalysisException;

### 功能
获取算法配置参数

### 参数
* fullPath:算法配置文件名全路径，为空时获取本地配置文件`local.conf:algo_conf`，默认是`/usr/local/ev_sdk/model/algo_config.json`

### 返回值
函数调用后返回VasiResult。其中bRet表示成功与否，strRlt表示具体信息。

* bRet表示成功时，strRlt表示算法配置参数，每个算法配置参数可能有所不同，由具体算法为准，示例

		{
		    "draw_roi_area": 1,
		    "draw_result": 1,
		    "show_result": 0,
		    "gpu_id": 0,
		    "threshold_value": 0.6
		}

* bRet表示失败时，strRlt表示具体的失败信息

# 服务状态信息
### 原型
VasiResult status() throws AnalysisException

### 功能
获取vas当前运行状态信息

### 参数
无参数

### 返回值
函数调用后返回VasiResult。其中bRet表示成功与否，strRlt表示具体信息。

* bRet表示成功时，strRlt表示运行状态信息，json格式，例如

        {
            "whether_authorized": true,
            "license_data": {
                "license": "b52f92d8ad261f16e8cafe2a2f6f9589d2f8c77533b92c0f644cf1058557e52a128fe369318f3af5bf6bf229f70bf48820df293dc7dbaf5431e02963e5e3b942febe6ca45de5bee2c1080d91467cdcedfa55555e47bc4955ac3d4e2cbdf6312ec0831a26f1d100f1921576a195aa1666a078ccf6515b40b4060cc08369485532",
                "version": 7
            },
            "whether_run_config": true,
            "whether_running": true,
            "whether_multi_camera": true,
            "whether_acquire_lock": true,
            "whether_time_segment": true,
            "whether_time_segment_ok": false,
            "whether_callback": true,
            "whether_callback_ok": 0,
            "whether_push_url": true,
            "whether_push_url_ok": 0,
            "camera_list": [
                {
                    "cid": "123450",
                    "whether_connected": false
                },
                {
                    "cid": "123451",
                    "whether_connected": false
                },
                {
                    "cid": "123452",
                    "whether_connected": false
                }
            ]
        }

	* whether_authorized:是否授权，通过授权才有以下所有信息
		* license_data:授权的相关信息，是个json对象
		* whether_run_config:是否有运行参数，有运行参数时才有以下所有信息
			* whether_running:工作线程是否在运行，在运行时才有以下所有信息
				* whether_multi_camera:是否配置了多路摄像头
				* whether_acquire_lock:是否请求到可运行锁
				* whether_time_segment:是否有运行时间段
				* whether_time_segment_ok:当前是否处在运行时间段内
				* whether_callback:是否配置了callback地址(http)
				* whether_callback_ok:最近一次报警回调是否成功--没有配置或没触发调用时为0，失败为-1，成功为1
				* whether_push_url:是否配置推流地址(rtmp)
				* whether_push_url_ok:最近一次推流是否成功--没有配置或多路或没触发调用时为0，失败为-1，成功为1
				* camera_list:摄像头状态信息，是个json数组，成员信息如下{cid,whether_connected}
				* cid:摄像头ID
				* whether_connected:是否连接成功

* bRet表示失败时，strRlt表示具体的失败信息

* 该接口可用于存活检测，例如:除vas进程不存在、status接口调用不成功外、`(whether_authorized && whether_run_config && !whether_running)`也表示处在卡死状态


# qps信息
### 原型
VasiResult qpsInfo() throws AnalysisException

### 功能
获取qps相关信息，包括授权中配置的qps，及实际运行的qps（一秒内可处理的帧数）

### 参数
无参

### 返回值
函数调用后，返回VasiResult。其中bRet表示成功与否，strRlt表示具体信息

* bRet表示成功时，strRlt表示运行状态信息，json格式，例如

        {
            "auth_qps": 5.00,
            "real_qps": 16.15
        }

	* auth_qps:授权时的qps，没有授权为-1，授权无qps为0，其它为授权的qps值
	* real_qps:实际部署时qps值，动态计算取得（最近10次实际qps的平均值），没跑过算法时为0.00
	 
* bRet表示失败时，strRlt表示具体的失败信息

# 授权管理
### 原型
VasiResult license(string content) throws AnalysisException

### 功能
授权管理，提供四个功能，分别是获取参考码，查询授权信息，更改授权信息，清除授权信息

### 参数
* content:请求内容，不同功的能请求内容有所不同

### 返回值
函数调用后，返回VasiResult。其中bRet表示成功与否，strRlt表示具体信息

* bRet表示成功时，strRlt不同的功能返回信息有所不同
* bRet表示失败时，strRlt表示具体的失败信息

## 获取参考码
* 请求
 * 示例

			｛
				"function": "get_reference",
				"isNetworking": 0
			｝

		* function:固定为`get_reference`
		* isNetworking:是否请求联网校验的参考码，1表示是，其它表示否，默认否，可选参数 
	
* 返回
 * 成功，示例 

			{
    			"version": 7,
    			"reference": "4ecf97189dfb9d94df43d9d14fe754ebf2707c614a50a09d5eed8ea953656695",
    			"disk_serial": "S3YLNX0K533123P",
    			"mac": "02:42:ac:11:00:0d"
			}

		* version:版本号
		* reference:参考码
		* 其它信息（版本不同也有所不同）

## 查询授权信息
* 请求
 * 示例

			｛
				"function": "query_license"
			｝

			* function:固定为`query_license`
	
* 返回
 * 成功，示例 

			{
			    "license": "b52f92d8ad261f16e8cafe2a2f6f9589d2f8c77533b92c0f644cf1058557e52a128fe369318f3af5bf6bf229f70bf48820df293dc7dbaf5431e02963e5e3b942febe6ca45de5bee2c1080d91467cdcedfa55555e47bc4955ac3d4e2cbdf6312ec0831a26f1d100f1921576a195aa1666a078ccf6515b40b4060cc08369485532",
			    "version": 7
			}

		* license:授权码
		* activation:激活码
		* version:版本号

## 修改授权信息
* 请求
 * 示例

			{
				"function": "update_license",
				"version": 7,
				"license": "b52f92d8ad261f16e8cafe2a2f6f9589d2f8c77533b92c0f644cf1058557e52a128fe369318f3af5bf6bf229f70bf48820df293dc7dbaf5431e02963e5e3b942febe6ca45de5bee2c1080d91467cdcedfa55555e47bc4955ac3d4e2cbdf6312ec0831a26f1d100f1921576a195aa1666a078ccf6515b40b4060cc08369485532",
				"activation": "RDVG4RDVGFPC99993EA19F8334F667714CC5168D39BC3B0B052C2961F506AAAA"
			}

		* function:固定为`update_license`
		* license:授权码
		* url:联网校验服务器地址(http服务)，可选参数
		* activation:激活码，可选参数
		* timestamp:过期时间，可选参数
		* qps:最大请求量，可选参数
		* version:版本号
	
* 返回
 * 成功，示例

			{
			    "err_code": 0,
			    "err_msg": "succeed"
			}

## 清除授权信息
* 请求
 * 示例

			{
				"function": "update_license"
			}

			* function:固定为`update_license`
			* 无license相关信息
	
* 返回
 * 成功，示例 

			{
			    "err_code": 0,
			    "err_msg": "succeed"
			}

# 测试工具
在安装目录下，运行`./testVas -h`，输出帮助信息如下

	---------------------------------
	usage:
	  -h  --help        show help information
	  -s  --server      ICE server host. default: 127.0.0.1
	  -p  --port        ICE server port. default: 10000
	  -f  --function    ICE function interface, for example:
	                    1.apply
	                    2.test
	                    3.algoConfig
	                    4.getRunConfig
	                    5.getAlgoConfig
	                    6.status
	                    7.qpsInfo
	                    8.license
	  -c  --content     1&2&3&9:json file
	  -o  --optional    [optional] for example:3&5:fullPath
	---------------------------------

 例如

    ./testVas -f 1 -c run.conf.1
	./testVas -f 1 -c run.conf.2
	./testVas -f 1 -c run.conf.3
	./testVas -f 2 -c run.conf.3
	./testVas -f 3 -c algo_config.sample
	./testVas -f 3 -c algo_config.sample -o /usr/local/ev_sdk/model/algo_config.json
	./testVas -f 4
	./testVas -f 5
	./testVas -f 5 -o /usr/local/ev_sdk/model/algo_config.json
	./testVas -f 6 
	./testVas -f 7
	./testVas -f 8 -c get_reference.sample
	./testVas -f 8 -c query_license.sample
	./testVas -f 8 -c update_license.sample

---