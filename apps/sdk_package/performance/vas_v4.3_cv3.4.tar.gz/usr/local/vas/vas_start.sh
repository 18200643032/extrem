#!/bin/bash

#脚本说明
# 功能:用于启动vas,成功返回0,其它返回非0,无参数.

vas_path="/usr/local/vas/vas.sh"
vas_data_path="/usr/local/vas/vas_data"

# 建立软件链接目录，并生成相关子目录
#   目标目录${data_path},例如:/data/0964ee64b0be/vas_data,不存在时会创建
#   软目录${vas_data_path},链接到${data_path},例如:/usr/local/vas/vas_data,链接到/data/0964ee64b0be/vas_data
#   相关子目录,参考本地配置文件local.conf
#     /usr/local/vas/vas_data/log
#     /usr/local/vas/vas_data/pic
if [[ ! -d ${vas_data_path} ]]; then
	echo "${vas_data_path} does not exist, ln -s ..."

	data_path="/data"
	contain_id=$(cat /proc/1/cpuset | cut -c9-)
	if [ -z "${contain_id}" ]; then
		echo "get contain_id failed."
		exit -1
	fi	
	
	if [ ${#contain_id} -lt 12 ]; then
		echo "contain_id length < 12, invalid."
		exit -1
	fi
	contain_id=${contain_id:0:12}
	data_path="${data_path}/${contain_id}/vas_data"
	
	# for example: /data/0964ee64b0be/vas_data
	if [[ ! -d ${data_path} ]]; then	
		echo "${data_path} does not exist, mkdir -p ..."
		mkdir -p ${data_path}
		ret=$?
		if [[ ${ret} -ne 0 ]]; then
			echo "mkdir -p ${data_path}, failed."
			exit -1
		fi
	fi

	# for example: ln -s ${vas_data_path} /data/0964ee64b0be/vas_data
	ln -s ${data_path} ${vas_data_path}
	ret=$?
	if [[ ${ret} -ne 0 ]]; then
		echo "ln -s ${data_path} ${vas_data_path}, failed."
		exit -1
	fi
	
	# for example: ${vas_data_path}/pic
	pic_path="${vas_data_path}/pic"
	if [[ ! -d ${pic_path} ]]; then	
		echo "${pic_path} does not exist, mkdir ..."
		mkdir ${pic_path}
		ret=$?
		if [[ ${ret} -ne 0 ]]; then
			echo "mkdir ${pic_path}, failed."
			exit -1
		fi
	fi
	
	# for example: ${vas_data_path}/log
	log_path="${vas_data_path}/log"
	if [[ ! -d ${log_path} ]]; then	
		echo "${log_path} does not exist, mkdir ..."
		mkdir ${log_path}
		ret=$?
		if [[ ${ret} -ne 0 ]]; then
			echo "mkdir ${log_path}, failed."
			exit -1
		fi
	fi
fi 

# 服务是否启动
pids=$(pidof vas)
if [ ! -z "${pids}" ]; then
	echo "vas already started, ${pids}"
	echo "please stop first."	
	exit -1
fi

# 启动
${vas_path}
ret=$?
if [[ ${ret} -eq 0 ]]; then
	sleep 1
	echo "start succeed, $(pidof vas)"
else
	echo "start failed, please check."
fi

exit ${ret}
