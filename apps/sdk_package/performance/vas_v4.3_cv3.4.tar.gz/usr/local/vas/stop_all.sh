#!/bin/bash

#脚本说明
# 功能:用于停止vas,nginx服务,无参数.

# vas
/usr/local/vas/vas_stop.sh

# nginx
/usr/local/nginx/script/nginx_stop.sh

exit 0


